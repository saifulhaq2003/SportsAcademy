package academy.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import academy.beans.FeedBack;
import academy.dao.MemberDao;

/**
 * Servlet implementation class MemberFeedback
 */
@WebServlet("/MemberFeedback")
public class MemberFeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberFeedback() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String name=request.getParameter("name").trim();
		String email=request.getParameter("email");
		String radio=request.getParameter("rating");
		String remarks=request.getParameter("remarks");
		
		java.util.Date d=new java.util.Date();
		
		long dt=d.getTime();
		
		java.sql.Date sd=new java.sql.Date(dt);
		
		MemberDao dao=new MemberDao();
		
		FeedBack feedback=new FeedBack(email, name, radio, remarks, sd);
		
		int status=dao.addFeedBack(feedback);
		
		if(status>0)
		{
			request.setAttribute("feedback", "Thank you for your feedback!");
			
			RequestDispatcher rd=request.getRequestDispatcher("/member/member_feedback.jsp");
			rd.forward(request, response);
		}
		
		
	
	}
	
	

}
