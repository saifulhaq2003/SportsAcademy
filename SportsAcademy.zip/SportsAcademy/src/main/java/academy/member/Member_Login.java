package academy.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import academy.dao.MemberDao;

/**
 * Servlet implementation class Member_Login
 */
@WebServlet("/Member_Login")
public class Member_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Member_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Post method from member_login is being called");
		
		String id=request.getParameter("member_id").trim();
		String pass=request.getParameter("member_pass");
		String cookieStatus=request.getParameter("chkcookie");
		System.out.println("Member id is "+id);
		System.out.println("Password is "+pass);
		MemberDao dao=new MemberDao();
		boolean status=dao.login(id, pass);
		
		if(status)//status==true
		{
			if(cookieStatus!=null)
			{				
			//cookie code
			Cookie c=new Cookie("userCookie", id+"#"+pass);
			c.setMaxAge(24*60*60);
			response.addCookie(c);//sending cookie to client machine
			System.out.println("Cookie created");
			}
			HttpSession session=request.getSession();//it will create a session
			session.setAttribute("sessionKey", id);
			session.setAttribute("role", "member");
			System.out.println("session Id-"+session.getId());
			
			
			response.sendRedirect("/SportsAcademy/member/member_home.jsp");
		}
		else
		{
			request.setAttribute("login_message", "Invalid Credentials");
			RequestDispatcher rd=request.getRequestDispatcher("/member/member_login.jsp");
			rd.forward(request, response);
		}

	}

}
