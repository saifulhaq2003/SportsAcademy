package academy.dbinfo;

import java.sql.*;
import java.util.ResourceBundle;//it is used to read data from properties file
public class DataBaseConnection 
{
	private static Connection con;
	private static ResourceBundle rb;
	public static Connection openConnection()
	{
		//factory method -> it is used to create the object of a class
		// Calendar c=Calendar.getInstance(); Calendar is an abstract class, but using its factory method getInstance(), we can create its object
		try
		{
			rb=ResourceBundle.getBundle("academy/dbinfo/database_info");//gives reference of file to resource bundle 
			//System.out.println(rb.getString("db.userId"));
			String id=rb.getString("db.userId");
			String pass=rb.getString("db.userPass");
			String url=rb.getString("db.url");
			Class.forName("com.mysql.cj.jdbc.Driver");//forName() is the factory method that is used to create the object of the driver
			/*
			 * con=DriverManager.getConnection("jdbc:mysql://localhost:3306/academy_db",
			 * "root", "root");
			 */
			con=DriverManager.getConnection(url, id, pass);
			//jdbc:mysql -> subprotocol -> jdbc request is passed to mysql
			//localhost -> this is the name or IP address of the machine where database has been installed
			//3306 is the port number of the database
			//academy_db -> name of our database
			//1st root is database user id
			//2nd root is database password
		}
		//   raised by forName()        getConnection()
		catch(ClassNotFoundException | SQLException cse)
		{
			cse.printStackTrace();
		}
		return con;
	}
	




	public static void closeConnection()
	{
		try
		{
			if(con!=null)
				con.close();
		}	
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * Connection cn=openConnection(); System.out.println(cn);
	 * 
	 * }
	 */



}//class close