package academy.common;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.catalina.startup.UserConfig;

import academy.beans.UserContact;
import academy.dao.MemberDao;

/**
 * Servlet implementation class Common_Login
 */
@WebServlet("/Contact")
public class Contact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Contact() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Post method from common_login is being called");
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String query=request.getParameter("query");
		
		java.util.Date d=new java.util.Date();
		
		long dt=d.getTime();//convert current date into long
		
		java.sql.Date sd = new java.sql.Date(dt);
		
		
		UserContact contact=new UserContact(name, email, phone, query, sd);
		
		MemberDao dao=new MemberDao();
		int status=dao.addContact(contact);
		if(status>0)
		{
			System.out.println("Contact Added Successfully");
			
			request.setAttribute("msg", "Thank You for contacting us, we will reach you soon");
			RequestDispatcher rd=request.getRequestDispatcher("/jsp/index.jsp");
			rd.forward(request, response);//forwards request on given url
			
			
			
		}
		
		
		
	}

}
