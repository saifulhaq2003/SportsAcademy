package academy.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import academy.beans.Event;
import academy.dao.AdminDao;

/**
 * Servlet implementation class AddEvent
 */
@WebServlet("/AddEvent")
public class AddEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEvent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String name=request.getParameter("name");
		String venue=request.getParameter("venue");
		String organizer=request.getParameter("organizer");
		String description=request.getParameter("description");
		String date=request.getParameter("date");
		
		Event e=new Event(name, venue, organizer, description, date);
		AdminDao dao=new AdminDao();
		int status=dao.addEvent(e);
		
		if(status>0)
		{
			System.out.println("Event added successfully");
			response.sendRedirect("/SportsAcademy/admin/event.jsp?msg=Event added successfully");
			//from ? it is called as query parameter
			//the first parameter is followed by a ? and if we want to add further more parameters, it can be added using a & as a separator
			
		}
		
		
	}

}
