package academy.beans;

public class Event 
{
	private String name, venue, organizer, description, date;
	private int Id;
	
	
	public Event()
	{
		
	}
	
	public Event(String name, String venue, String organizer, String description, String date) 
	{
		this.name = name;
		this.venue = venue;
		this.organizer = organizer;
		this.description = description;
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getOrganizer() {
		return organizer;
	}
	public void setOrganizer(String organizer) {
		this.organizer = organizer;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
}
