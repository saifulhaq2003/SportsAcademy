package academy.beans;

import java.sql.Date;

public class Member 
{
	
	private String id, password, name, email, phone, gender, address;
	private String sportsName;
	private int age;
	private Date date;
	
	
	public Member()
	{
		
	}
	public Member(String id, String password, String name, String email, String gender, String address,
			String sportsName, String phone, int age) 
	{
		this.id = id;
		this.password = password;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.address = address;
		this.sportsName = sportsName;
		this.phone = phone;
		this.age = age;
	}
	
	
	public Member(String id, String password, String name, String email, String gender, String address,
			String sportsName, String phone, int age, Date date) 
	{
		this.id = id;
		this.password = password;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.address = address;
		this.sportsName = sportsName;
		this.phone = phone;
		this.age = age;
		this.date = date;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSportsName() {
		return sportsName;
	}
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}