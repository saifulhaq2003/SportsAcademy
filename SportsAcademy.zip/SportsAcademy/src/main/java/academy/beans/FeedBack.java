package academy.beans;

import java.sql.Date;

public class FeedBack 
{
	private String email,name,radio,remarks;
	
	public FeedBack()
	{
		
	}
	
	
	public FeedBack(String email, String name, String radio, String remarks, Date date) {
		this.email = email;
		this.name = name;
		this.radio = radio;
		this.remarks = remarks;
		this.date = date;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getRadio() {
		return radio;
	}


	public void setRadio(String radio) {
		this.radio = radio;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public int getSerial_number() {
		return serial_number;
	}


	public void setSerial_number(int serial_number) {
		this.serial_number = serial_number;
	}


	private Date date;

	
	private int serial_number;







}