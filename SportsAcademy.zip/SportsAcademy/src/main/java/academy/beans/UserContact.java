package academy.beans;

import java.sql.Date;

public class UserContact {
	private String name, email, phone, question;
	private Date date;
	private int serial_number;
	
	
	
	
	public UserContact(String name, String email, String phone, String question, Date date) {
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.question = question;
		this.date = date;
	}
	public UserContact() 
	{
	
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getSerial_number() {
		return serial_number;
	}
	public void setSerial_number(int serial_number) {
		this.serial_number = serial_number;
	}
	
	
	
	
}
