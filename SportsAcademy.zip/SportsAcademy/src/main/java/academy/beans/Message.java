package academy.beans;

public class Message {
	
	
	

	private String slogan;

	
	
	public Message()
	{
		
	}
	
	public String getSlogan() {
		return slogan;
	}

	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}
	
	
}
