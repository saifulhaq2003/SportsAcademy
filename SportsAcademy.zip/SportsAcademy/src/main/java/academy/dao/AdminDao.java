package academy.dao;

import java.sql.*;
import java.util.ArrayList;



/*import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;*/

import academy.beans.Event;
import academy.beans.FeedBack;
import academy.beans.UserContact;
import academy.beans.Member;
import academy.beans.Notice;
import academy.beans.Sports;
import academy.dbinfo.DataBaseConnection;

public class AdminDao 
{
	//Create individual row
	//create object of bean class
	//add into array list
	// return array list
	
	
	
	public ArrayList<UserContact> viewContacts()
	{
		ArrayList<UserContact> contactList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_query="select * from contact order by date desc";//limit 10
		
		try
		{
			ps=con.prepareStatement(select_query);
			
			rs=ps.executeQuery();
			while(rs.next())
			{
				//serial_number, name, email, phone, question, date
				String name=rs.getString("name");
				String email=rs.getString("email");
				String phone=rs.getString("phone");
				String question=rs.getString("question");
				java.sql.Date d=rs.getDate("date");
				
				UserContact contact=new UserContact(name, email, phone, question, d);
				
				contact.setSerial_number(rs.getInt("serial_number"));//adding serial no. into bean class
				
				contactList.add(contact);				
			}
			
			
			
		}
		
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}	
		return contactList;
	}
	
//	feedback n members, n bring to index page when feedback is entered and display a message like thank u for ur feedback
	public ArrayList<FeedBack> viewFeedBack()
	{
		ArrayList<FeedBack> feedbackList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_query="select * from feedback order by date desc";
		//serial_number, name, email, rating, remarks, date
		try
		{
			ps=con.prepareStatement(select_query);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				String name=rs.getString("name");
				String email=rs.getString("email");
				String rating=rs.getString("rating");
				String remark=rs.getString("remarks");
				java.sql.Date d=rs.getDate("date");
				
				FeedBack feedback=new FeedBack(email, name, rating, remark, d);
				feedbackList.add(feedback);
				
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return feedbackList;

	}
	
	public ArrayList<Member> viewRegistration()
	{
		ArrayList<Member> registrationList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		//member_id, password, name, email, phone, age, gender, sports_name, address, date
		String select_query="select * from member order by date";
		
		try
		{
			ps=con.prepareStatement(select_query);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				String id=rs.getString("member_id");
				String password=rs.getString("password");
				String name=rs.getString("name");
				String email=rs.getString("email");
				String phone=rs.getString("phone");
				int age=rs.getInt("age");
				String gender=rs.getString("gender");
				String sports_name=rs.getString("sports_name");
				String address=rs.getString("address");
				java.sql.Date d=rs.getDate("date");
				
				Member member=new Member(id, password, name, email, gender, address, sports_name, phone, age, d);
				
				registrationList.add(member);
				
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return registrationList;
	}
	
	
	
	
	public int addEvent(Event e)
	{
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String insert_query="insert into event(name, venue, organizer, description, date) values (?,?,?,?,?)";
		int status=0;
		try
		{
			ps=con.prepareStatement(insert_query);
			
			ps.setString(1, e.getName());
			ps.setString(2, e.getVenue());
			ps.setString(3, e.getOrganizer());
			ps.setString(4, e.getDescription());
			ps.setString(5, e.getDate());
			
			System.out.println(ps);
			status=ps.executeUpdate();
			
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
				{
					ps.close();
				}
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		return status;
	}

	

	
	
	
	
	/* delete contact code starts */
	public int deleteContact(String[] numbers) 
	{
		int status=0;
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		
		String delete_query="delete from contact where serial_number=?";
		
		try
		{
			con.setAutoCommit(false);
			ps=con.prepareStatement(delete_query);
			
			for(int i=0; i< numbers.length; i++)
			{
				ps.setInt(1, Integer.parseInt(numbers[i]));
				ps.addBatch();//batch statement all queries are stored into buffer
				
				/*
				 * System.out.println(ps); ps.executeUpdate();
				 */
			}
			int []status_arr=ps.executeBatch();//batch execution for all the queries via RDBMS
			
			for(int n:status_arr)
			{
				if(n<0)
				{
					status=0;
					break;
				}
				
				else
				{
					con.setAutoCommit(true);
					status=1;
				}
			}
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return status;
	}
	
	/* delete contact code ends */
	
	/* view event code starts here */
	
	public ArrayList<Event> viewEvent()
	{
		ArrayList<Event> eventList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_Query="select * from event order by date";
		
		try
		{
			ps=con.prepareStatement(select_Query);
			
			rs=ps.executeQuery();
			while(rs.next())
			{
				//Id, name, venue, organizer, description, date
				int id=Integer.parseInt(rs.getString("Id"));
				String name=rs.getString("name");
				String venue=rs.getString("venue");
				String organizer=rs.getString("organizer");
				String description=rs.getString("description");
				String date=rs.getString("date");
				
				Event e=new Event(name, venue, organizer, description, date);
				e.setId(id);
				eventList.add(e);
			}
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return eventList;
		
	}
	
	
	/* view event code ends here */
	
	
	/* delete event code starts here*/

	public int deleteEvent(String []numbers) 
	{
		int status=0;
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String delete_query="delete from event where Id=?";
		
		
		try
		{
			con.setAutoCommit(false);
			ps=con.prepareStatement(delete_query);
			
			for(int i=0; i<numbers.length; i++)
			{
				ps.setInt(1, Integer.parseInt(numbers[i]));
				ps.addBatch();
			}
			
			int status_arr[]=ps.executeBatch();
			
			for(int n:status_arr)
			{
				if(n<0)
				{
					status=0;
					break;
				}
				
				else
				{
					con.setAutoCommit(true);
					status=1;
				}
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return status;
	}

	/* delete event code ends here*/

	/* add sports code starts here*/
	
	
	public int addSports(Sports s) 
	{
		int status=0;
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String insert_query="insert into sports_details(sports_name, type, charge, duration, services) values (?,?,?,?,?)";

		try
		{
			ps=con.prepareStatement(insert_query);
			ps.setString(1, s.getName());
			ps.setString(2, s.getType());
			ps.setString(3, s.getCharge());
			ps.setString(4, s.getDuration());
			ps.setString(5, s.getServices());
			
			System.out.println(ps);
			status=ps.executeUpdate();
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return status;
	}
	
	/* add sports code ends here*/
	
	
	/* view sports code starts here*/
	
	public ArrayList<Sports> viewSports()
	{
		ArrayList<Sports> sportsList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_query="select * from sports_details";
		
		try
		{
			ps=con.prepareStatement(select_query);
			
			rs=ps.executeQuery();
			while(rs.next())
			{
				//id, sports_name, type, charge, duration, services
				int id=Integer.parseInt(rs.getString("id"));
				String name=rs.getString("sports_name");
				String type=rs.getString("type");
				String charge=rs.getString("charge");
				String duration=rs.getString("duration");
				String services=rs.getString("services");
				
				Sports s=new Sports(name, type, duration, charge, services);
				s.setId(id);
				
				sportsList.add(s);
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return sportsList;
		
	}

	/* view sports code ends here*/
	
	/* delete sports code starts here*/
	
	public int deleteSports(String[] numbers) 
	{
		int status=0;
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String delete_query="delete from notice where id=?";
		try
		{
			con.setAutoCommit(false);
			ps=con.prepareStatement(delete_query);
			
			for(int i=0;i<numbers.length;i++)
			{
				ps.setInt(1, Integer.parseInt(numbers[i]));
				ps.addBatch();
			}
			
			
			int status_arr[]=ps.executeBatch();
			for(int n:status_arr)
			{
				if(n<0)
				{
					status=0;
					break;
				}
				else
				{
					con.setAutoCommit(true);
					status=1;
				}
			}
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		
		return status;
	}

	public int addNotice(Notice n) 
	{
		
		int status=0;
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String insert_query="insert into notice(content,date) values (?,?)";
		
		try
		{
			ps=con.prepareStatement(insert_query);
			
			ps.setString(1, n.getNotice());

			ps.setString(2, n.getDate());
			
			status=ps.executeUpdate();
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return status;
	}
	
	public ArrayList<Notice> viewNotice()
	{
		ArrayList<Notice> noticeList=new ArrayList<>();
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_query="select * from notice";
		
		try
		{
			ps=con.prepareStatement(select_query);
			
			rs=ps.executeQuery();
			while(rs.next())
			{
				//id, sports_name, type, charge, duration, services
				int id=Integer.parseInt(rs.getString("Id"));
				String content=rs.getString("content");
				
				String date=rs.getString("date");
				Notice n=new Notice(content,date);
				n.setId(id);
				
				noticeList.add(n);
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		
		return noticeList;
		
	}

	
	
}
