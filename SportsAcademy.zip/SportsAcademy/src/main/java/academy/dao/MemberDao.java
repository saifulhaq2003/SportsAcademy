package academy.dao;

import academy.beans.FeedBack;
import academy.beans.Member;
import academy.beans.UserContact;
import academy.dbinfo.DataBaseConnection;

import java.sql.*;

public class MemberDao {

	public int addContact(UserContact contact)
	{
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;//preparedstatement is a class that on behalf of java communicates with db
		int status=0;
		String insert_query="insert into contact(name, email, phone, question, date) values(?,?,?,?,?)";
		
		try 
		{
			ps=con.prepareStatement(insert_query);
			//it passes the query to the database and db parser/compiler will compile the query and keep it into buffer
			//and assign that address to ps
			
			ps.setString(1, contact.getName());
			ps.setString(2, contact.getEmail());
			ps.setString(3, contact.getPhone());
			ps.setString(4, contact.getQuestion());
			ps.setDate(5, contact.getDate());
			
			System.out.println(ps);
			
			status=ps.executeUpdate();//to insert data into table
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
			ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();			
		}
		
		
		
		
		return status;
	}
	
	public int addFeedBack(FeedBack feedback)
	{
		
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		int status=0;
		String insert_query="insert into feedback(name, email, rating, remarks, date) values (?,?,?,?,?)";
		try
		{
			ps=con.prepareStatement(insert_query);
			
			ps.setString(1, feedback.getName());
			ps.setString(2, feedback.getEmail());
			ps.setString(3, feedback.getRadio());
			ps.setString(4, feedback.getRemarks());
			ps.setDate(5, feedback.getDate());
			
			System.out.println(ps);
			status=ps.executeUpdate();
					
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		return status;
	}
	
	
	//Member register code starts
	
	public int addRegistration(Member m)
	{
		Connection con=DataBaseConnection.openConnection();
		
		PreparedStatement ps=null;
		int status=0;
		String insert_query="insert into member(member_id, password, name, email, phone, age, gender, sports_name, address, date) values(?,?,?,?,?,?,?,?,?,?)";
		
		try
		{
			ps=con.prepareStatement(insert_query);
			
			
			ps.setString(1, m.getId());
			ps.setString(2, m.getPassword());
			ps.setString(3, m.getName());
			ps.setString(4, m.getEmail());
			ps.setString(5, m.getPhone());
			ps.setInt(6, m.getAge());
			ps.setString(7, m.getGender());
			ps.setString(8, m.getSportsName());
			ps.setString(9, m.getAddress());
			ps.setDate(10, m.getDate());
			System.out.println(ps);
			status=ps.executeUpdate();
		}
		catch(SQLException se)
		{			
			se.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return status;
		
	}
	//Member register code ends
	
	
	//member login code starts here
	public boolean login(String id,String pass)
	{
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String select_query="select member_id,password from member where member_id=? and password=?";
		boolean status=false;
		try
		{
			ps=con.prepareStatement(select_query);
			ps.setString(1, id);
			ps.setString(2, pass);
			System.out.println(ps);
			
			rs=ps.executeQuery();
			if(rs.next()==true)//will check for data existence
			{
				status=true;
			}
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return status;
	}
	//member login code ends here
	
	
	//member view profile code starts here
	
	public Member viewProfile(String memberId)
	{
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		Member m=null;
		String select_query="select * from member where member_id=?";
		
		try
		{
			ps=con.prepareStatement(select_query);
			ps.setString(1, memberId);
			System.out.println(ps);
			rs=ps.executeQuery();
			rs.next();
			
			//member_id, password, name, email, phone, age, gender, sports_name, address, date
			String pass=rs.getString("password");
			String email=rs.getString("email");
			String name=rs.getString("name");
			String phone=rs.getString("phone");
			String gender=rs.getString("gender");
			String sports_name=rs.getString("sports_name");
			String address=rs.getString("address");
			int age=rs.getInt("age");
			
			m=new Member(memberId, pass, name, email, gender, address, sports_name, phone, age);
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null)
					rs.close();
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		
		return m;//returning member class object who has logged in
	}
	
	//member view profile code ends here
	

	
	// member edit profile code starts
	public int editProfile(Member m) 
	{
		Connection con=DataBaseConnection.openConnection();
		PreparedStatement ps=null;
		
		String update_query="update member set email=?, phone=?, address=? where member_id=?";
		int status=0;
		
		try
		{
			ps=con.prepareStatement(update_query);
			
			ps.setString(1, m.getEmail());
			ps.setString(2, m.getPhone());
			ps.setString(3, m.getAddress());
			ps.setString(4, m.getId());
			
			System.out.println(ps);
			
			status=ps.executeUpdate();//to execute update query
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try
			{
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			DataBaseConnection.closeConnection();
		}
		return status;
	}
	
	// member edit profile code ends
	
}
